import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import fs from 'node:fs/promises';

const app = await fs.readFile('./public/app.js','utf8');
assert.match(app,/computeBodyEstimate/);
assert.match(app,/openProgramBuilder/);
assert.match(app,/estimateNutritionLocal/);
assert.match(app,/Export full JSON/);
assert.match(app,/rollingWeight/);
assert.match(app,/Update program going forward/);

const port = 4199;
const child = spawn(process.execPath,['server.mjs'],{env:{...process.env,PORT:String(port)},stdio:['ignore','pipe','pipe']});
await new Promise((resolve,reject)=>{
  const timer=setTimeout(()=>reject(new Error('server did not start')),3000);
  child.stdout.on('data',buf=>{if(String(buf).includes('Fitness tracker running')){clearTimeout(timer);resolve();}});
  child.on('exit',code=>reject(new Error(`server exited ${code}`)));
});
try {
  const home=await fetch(`http://127.0.0.1:${port}/`);
  assert.equal(home.status,200);
  assert.match(await home.text(),/Forge/);
  const css=await fetch(`http://127.0.0.1:${port}/styles.css`);
  assert.equal(css.status,200);
  const js=await fetch(`http://127.0.0.1:${port}/app.js`);
  assert.equal(js.status,200);
  const status=await fetch(`http://127.0.0.1:${port}/api/status`);
  assert.equal(status.status,200);
  const body=await status.json();
  assert.equal(body.aiConfigured,false);
  const ai=await fetch(`http://127.0.0.1:${port}/api/nutrition-estimate`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({description:'200 g cottage cheese'})});
  assert.equal(ai.status,503);
  console.log('All smoke tests passed.');
} finally {
  child.kill('SIGTERM');
}
