# Forge — Personal Fitness & Body Composition Tracker

Forge is an offline-first, single-user fitness tracker built from the supplied specification. It runs in a browser, stores data locally, supports JSON/CSV backups, and can optionally use the OpenAI Responses API for natural-language nutrition estimates.

## Architecture

- **Client:** dependency-free HTML/CSS/JavaScript single-page application.
- **Persistence:** browser `localStorage`, with full JSON backup/restore and CSV exports.
- **Charts:** lightweight custom Canvas charts; no charting dependency or CDN required.
- **Server:** tiny Node.js static server using only Node built-ins.
- **AI nutrition:** optional server-side OpenAI integration. The API key is never placed in browser storage or client code.

This architecture was chosen because this is primarily a one-person tracker: it is easy to run, easy to back up, works without internet for core tracking, and avoids maintaining a database server. If the app later needs multi-device synchronization or multiple users, the data layer can be moved to SQLite/Postgres/Supabase without changing the conceptual model.

## Run locally

Requires Node.js 20+.

```bash
npm start
```

Open: `http://127.0.0.1:4173`

No `npm install` is required because there are no third-party runtime dependencies.

## Optional AI nutrition estimates

Core nutrition logging works without AI. Forge can extract explicit calorie/protein values from pasted summaries and has a small local reference list for several common foods.

For broader natural-language estimates, set an OpenAI API key on the **server**:

### macOS / Linux

```bash
OPENAI_API_KEY="your-key" npm start
```

### PowerShell

```powershell
$env:OPENAI_API_KEY="your-key"
npm start
```

Optionally choose a model:

```bash
OPENAI_MODEL="gpt-5.5" OPENAI_API_KEY="your-key" npm start
```

The included server uses the OpenAI Responses API. Nutrition estimates are explicitly labelled as estimates and are editable before being saved.

## Major workflows implemented

### Dashboard
- Daily calories/protein/weight/workout status
- 7-day weight/calorie/protein summaries
- DEXA-measured body fat shown separately from estimated current body fat
- Estimated body-fat range and confidence
- Weight trend chart

### Workout programs
- Program name + start/end dates
- Flexible sequence or weekday-based scheduling metadata
- Multiple workout days
- Exercises, sets, rep ranges, target weight and notes
- Start a session from the active program
- Previous performance displayed while logging
- Add/remove exercises and sets for an individual session
- Exercise substitutions are recorded on the completed workout
- Optional "update program going forward" behavior when substituting an exercise

### Workouts
- Date, program/day, exercise, weight, reps and sets
- Multiple sets per exercise
- Duplicate previous set by adding a set
- Volume calculations
- History and CSV export

### Nutrition
- Direct daily or meal-level entries
- Calories/protein plus optional fat/carbs/fibre
- Pasted ChatGPT summaries supported
- Explicit nutrition values are detected and preserved
- Local estimates for recognized foods/quantities
- Optional AI estimation
- Direct vs estimated source labels

### Weight
- Historical/date-specific entries
- 7- and 14-day moving averages
- Editable historical table
- Paste/import multiple rows
- Duplicate dates replace only after the user chooses to proceed in standard entry; bulk importer reports replacements
- CSV export

### DEXA / body composition
- Historical DEXA entry with partial-field support
- Total mass, BF%, fat mass, lean mass, bone mass and BF% excluding bone
- Measured-versus-estimated charting
- Between-scan estimate never overwrites a DEXA scan

### Body-fat estimate methodology

The latest DEXA is the measured baseline. The app then uses:
- current 7-day average weight (or latest weight if needed),
- recent protein versus active protein goal,
- resistance-training frequency,
- recent workout-volume trend,
- weight change since the DEXA.

It uses these inputs to estimate how much weight change is likely fat versus lean tissue, with a small allowance for water/glycogen. It returns a point estimate, range and qualitative confidence. This is a **heuristic estimate**, not a medical or measurement-grade body-composition test.

### Analytics
- 90-day calorie and protein averages
- Protein goal compliance
- Training frequency
- Weight versus calorie trend
- Protein trend
- Weekly workout frequency
- Exercise session-volume progression

### Data / settings
- Effective-dated goals
- Exercise library
- Full JSON export/restore
- Nutrition and workout CSV exports
- Light/dark mode
- Sample data loader

## Testing

Run:

```bash
npm test
```

The smoke test verifies:
- required major feature code is present,
- JavaScript parses,
- static server starts,
- HTML/CSS/JS assets load,
- AI status endpoint behaves correctly when no API key is configured.

For final acceptance, also open the app in a browser and manually test the key entry workflows on desktop and mobile-width windows.

## Backup recommendation

Use **Data / Settings → Export full JSON** periodically. That file can restore the application if browser storage is cleared.

## Deployment

Because the app has a small Node server, it can be deployed on any Node-capable host. For a purely local/private tracker, running `npm start` is simplest. If AI estimation is not needed, the `public/` directory can also be served as static files, though `/api/status` and the AI estimator will not be available.
