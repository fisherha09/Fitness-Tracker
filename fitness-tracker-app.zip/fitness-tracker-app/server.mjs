import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(__dirname, 'public');
const port = Number(process.env.PORT || 4173);

const mime = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

function json(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(body));
}

async function parseBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  if (!chunks.length) return {};
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

function extractOutputText(payload) {
  if (typeof payload?.output_text === 'string') return payload.output_text;
  for (const item of payload?.output || []) {
    for (const content of item?.content || []) {
      if (content?.type === 'output_text' && typeof content.text === 'string') return content.text;
    }
  }
  return '';
}

async function estimateNutritionWithOpenAI(description) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return null;
  const model = process.env.OPENAI_MODEL || 'gpt-5.5';
  const instructions = `You estimate nutrition from a user's food description. Return ONLY valid JSON with this exact shape: {"calories":number|null,"protein":number|null,"fat":number|null,"carbs":number|null,"fibre":number|null,"confidence":"Low"|"Moderate"|"High","assumptions":[string],"items":[{"description":string,"calories":number|null,"protein":number|null}]}. Preserve explicitly supplied nutrition values instead of re-estimating them. Use reasonable serving assumptions when needed. Do not claim laboratory precision.`;
  const response = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      instructions,
      input: description,
      max_output_tokens: 900,
    }),
  });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(`AI provider returned ${response.status}: ${text.slice(0, 300)}`);
  }
  const payload = await response.json();
  const text = extractOutputText(payload).trim().replace(/^```json\s*/i, '').replace(/```$/i, '').trim();
  return JSON.parse(text);
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    if (req.method === 'GET' && url.pathname === '/api/status') {
      return json(res, 200, { aiConfigured: Boolean(process.env.OPENAI_API_KEY), model: process.env.OPENAI_MODEL || null });
    }
    if (req.method === 'POST' && url.pathname === '/api/nutrition-estimate') {
      const body = await parseBody(req);
      if (!body.description || typeof body.description !== 'string') return json(res, 400, { error: 'Description is required.' });
      const result = await estimateNutritionWithOpenAI(body.description);
      if (!result) return json(res, 503, { error: 'AI is not configured. Add OPENAI_API_KEY to enable it.' });
      return json(res, 200, result);
    }

    let relative = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
    relative = path.normalize(relative).replace(/^([.][.][/\\])+/, '');
    const filePath = path.join(publicDir, relative);
    if (!filePath.startsWith(publicDir)) return json(res, 403, { error: 'Forbidden' });
    const data = await fs.readFile(filePath);
    res.writeHead(200, { 'Content-Type': mime[path.extname(filePath)] || 'application/octet-stream' });
    res.end(data);
  } catch (error) {
    if (error?.code === 'ENOENT') {
      try {
        const data = await fs.readFile(path.join(publicDir, 'index.html'));
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(data);
      } catch {
        json(res, 404, { error: 'Not found' });
      }
    } else {
      console.error(error);
      json(res, 500, { error: error.message || 'Server error' });
    }
  }
});

server.listen(port, '127.0.0.1', () => {
  console.log(`Fitness tracker running at http://127.0.0.1:${port}`);
  if (!process.env.OPENAI_API_KEY) console.log('AI nutrition estimation is disabled; local estimation remains available.');
});
